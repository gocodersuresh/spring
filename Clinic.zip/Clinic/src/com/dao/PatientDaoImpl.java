package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.model.Patient;

public class PatientDaoImpl {
	public static final String DRIVER_CLASS = "org.h2.Driver";
	private static final String URL = "jdbc:h2:~/test";
	private static final String USER = "";
	private static final String PASS = "";


	public static Connection getConnection()
	{
		try {
			Class.forName(DRIVER_CLASS);
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}
		Connection conn=null;
		try {
			conn=DriverManager.getConnection(URL,USER,PASS);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return conn;

	}
	public static boolean checkIfTablePresent()
	{
		boolean tableExists=false;
		Connection conn=getConnection();
		ResultSet rset = null;
		try {
			rset = conn.getMetaData().getTables(null, null, "PATIENT", null);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if (rset.next())
			{
				tableExists = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return tableExists;
	}
	public boolean save(Patient patientObj) throws SQLException
	{
		int result=0;
		boolean whetherSaved=false;
		createTable();
		Connection conn=getConnection();

		PreparedStatement ps=conn.prepareStatement("Insert into patient values(?,?)");
		ps.setString(1, patientObj.getPatientName());
		ps.setInt(2, patientObj.getPatientAge());

		result=ps.executeUpdate();

		ps.close();
		conn.close();
		if(result>0)
		{
			whetherSaved=true;
		}
		
		return whetherSaved;
	}
	
	public List<Patient> getPatientList() throws SQLException
	{
		List<Patient> patientList=new ArrayList<Patient>();	
		
		Connection conn=getConnection();

		Statement ps=conn.createStatement();
		ResultSet rs=ps.executeQuery("Select * from patient");
		while(rs.next())
		{
			Patient p=new Patient();		
			p.setPatientName(rs.getString("patientName"));
			p.setPatientAge(rs.getInt("patientAge"));
			patientList.add(p);
		}
		
		ps.close();
		conn.close();
		return patientList;
		
	}
	public static void createTable() throws SQLException
	{	

		Connection conn=getConnection();
		boolean ifTablePresent=checkIfTablePresent();
		if(!ifTablePresent)
		{				
			Statement st=null;
			st=conn.createStatement();
			st.execute("create table PATIENT(patientName varchar(30),patientAge varchar(30))");
			st.close();
		}
		conn.close();

	}
}
