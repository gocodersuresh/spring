package com.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.PatientDaoImpl;
import com.model.Patient;

/**
 * Servlet implementation class AppointmentController
 */
@WebServlet("/AppointmentController")
public class AppointmentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AppointmentController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String patientName=request.getParameter("patientName");
		int patientAge=Integer.parseInt(request.getParameter("patientAge"));
		//create object from values
		Patient patientObj=new Patient();
		patientObj.setPatientName(patientName);
		patientObj.setPatientAge(patientAge);
		
		PatientDaoImpl patientDao=new PatientDaoImpl();
		boolean result=false;
		try {
			result=patientDao.save(patientObj);			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String MSG="";
		if(result)
		{
			MSG="Record Inserted Successfully";
			
		}
		else
		{
			MSG="Some Error Occured";
		}
		
		RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
		request.setAttribute("MSG", MSG);
		rd.forward(request, response);
		
	}

}
