package com.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.service.PersonService;

public class TestStudent {
public static void main(String[] args) {
	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("classpath:/spring1.xml");
	//StudentService st=(StudentService)ctx.getBean(com.service.StudentService.class);
	PersonService st=(PersonService)ctx.getBean(com.service.PersonService.class);
	//st.save();
	st.list();
	
}
}
