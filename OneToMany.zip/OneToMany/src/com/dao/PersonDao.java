package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.model.Person;
@Component
public class PersonDao {
	@PersistenceContext
	EntityManager em;
	
	@Transactional
	public void save(Person person)
	{
		em.persist(person);
		System.out.println("Saved");
	}
	@Transactional 
	public void list()
	{
		List<Person> ps=em.createQuery("From Person p").getResultList();
		System.out.println("***************"+ps.get(0).getAddresses().get(0).getAddressId()+""+ps.get(0).getAddresses().get(0).getCityName()+""+ps.get(0).getAddresses().get(0).getPinCode());
		System.out.println("**********PID*****"+ps.get(0).getPersonId()+"*********NAME:"+ps.get(0).getPersonName());
	}
}
