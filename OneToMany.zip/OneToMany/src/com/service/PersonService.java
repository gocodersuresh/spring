package com.service;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.dao.PersonDao;
import com.model.Address;
import com.model.Person;

@Component
public class PersonService {
@Autowired
PersonDao personDao;

@Transactional 
public void save()
{
	Address ad=new Address();
	
	ad.setCityName("PUNE");
	ad.setPinCode(411027);
	List<Address> ads=new ArrayList<Address>();
	ads.add(ad);
	Person p=new Person();
	p.setPersonName("Steve");
	ad.setPerson(p);
	
	p.setAddresses(ads);
	personDao.save(p);
	
}
@Transactional
public void list()
{personDao.list();
	
}
}
