package com.main.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.main.model.Task;

@Service
public class TaskDaoImpl {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	String sql="CREATE TABLE TASK(taskId SERIAL,taskName VARCHAR(70))";
	public void initTable()
	{jdbcTemplate.execute("DROP TABLE TASK IF EXISTS");
	jdbcTemplate.execute(sql);
	}
	public void insertTask()
	{try{
		jdbcTemplate.update("INSERT INTO TASK VALUES(1,'SHIV')");
	}catch(Exception ex)
	{
		System.out.println(""+ex.getMessage());
	}
	}
	public void getAllRecords()
	{
		List<Map<String,Object>> taskListRows=jdbcTemplate.queryForList("SELECT * FROM TASK");
		for (Map<String, Object> map : taskListRows) {
			Set<String> st=map.keySet();
			for(String s:st)
			{
				System.out.println(map.get(s));

			}

		}
	}
	public void getAllRecordsBYBeanRowMapper()
	{
		List<Task> taskListRows=jdbcTemplate.query("SELECT * FROM TASK",new BeanPropertyRowMapper(Task.class));
		for(Task taskObj:taskListRows)
		{
			System.out.println("TaskID"+taskObj.getTaskId()+"   NAME "+taskObj.getTaskName());
		}

	}
	public void searchByName(String taskName)
	{
		Task taskObj = (Task)jdbcTemplate.queryForObject("SELECT * FROM TASK WHERE TASKNAME LIKE ?"
				, new Object[] { taskName },new BeanPropertyRowMapper(Task.class));
		System.out.println("FROM Search"+taskObj.getTaskId());
	}
}


